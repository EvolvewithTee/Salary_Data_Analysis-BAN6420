# Load necessary library
library(utils)  

# Define file paths
zip_file <- "Employee Profile.zip"
extraction_dir <- "Employee Profile"

# Unzip the file
unzip(zip_file, exdir = extraction_dir)

# Get the list of files in the extracted folder
files <- list.files(extraction_dir, pattern = "*.csv", full.names = TRUE)

# Read and display the first CSV file (assuming there's at least one CSV file)
if (length(files) > 0) {
  employee_data <- read.csv(files[1])  # Read the first CSV file
  print(employee_data)  # Display the data
} else {
  print("No CSV files found in the extracted folder.")
}

