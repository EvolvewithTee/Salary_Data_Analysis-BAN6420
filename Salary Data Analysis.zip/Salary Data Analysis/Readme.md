Salary Data Processing and Analysis

Project Overview

This project involves processing salary data using Python and R within a Jupyter Notebook environment. The key tasks include importing data, retrieving employee details, handling errors, exporting data, and working with zipped files.

Project Structure

graphql
Copy code
 Salary_Data_Analysis  
│──  salary_function.ipynb  # Jupyter Notebook containing the full analysis  
│──  unzip_and_display.R     # R script to unzip and display CSV data  
│──  Employee Profile        # Extracted folder containing employee data  
│──  Employee Profile.zip    # Zipped folder with exported CSV  
│──  README.md               # Instructions on using the project  
Setup Instructions

1. Prerequisites
Ensure you have the following installed:

Python (>=3.x)
Jupyter Notebook
R (>=4.x)
Required Python Libraries: pandas, os, zipfile
R package: utils (pre-installed in R)
2. How to Run the Project

Step 1: Run the Jupyter Notebook
Open Jupyter Notebook.
Load salary_analysis.ipynb.
Execute the notebook cells sequentially to:
Load and process the salary dataset.
Retrieve employee details.
Implement error handling.
Export data as a CSV file and zip it.

Step 2: Unzip and Display Data in R
Open RStudio or an R terminal.
Set the working directory to the folder containing Employee Profile.zip:
r
Copy code
setwd("C:/Users/pc/Documents")  # Adjust the path if needed
Run the R script to extract and display the data:
r
Copy code
source("unzip_and_display.R")
Expected Output

Jupyter Notebook successfully processes salary data and exports employee details to a zipped CSV.
Running the R script unzips the folder and displays the extracted employee data.
Author

Taiwo O. Elewode

17th March,2025